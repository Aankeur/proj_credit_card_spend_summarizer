import json
from sqlalchemy import text
from src.core.db import get_db_conn


def create_vector_table(embedding_dimension: int):
    """
    Create the pgvector extension and the knowledge_documents table.
    """

    db = get_db_conn()

    try:
        # Enable pgvector
        db.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))

        # Create vector table
        db.execute(text(f"""
                CREATE TABLE IF NOT EXISTS knowledge_documents (
                    id SERIAL PRIMARY KEY,
                    content TEXT NOT NULL,
                    embedding VECTOR({embedding_dimension}),
                    metadata JSONB
                )
                """))

        db.commit()

    finally:
        db.close()


def insert_documents(
    embedded_documents: list[dict],
) -> int:
    """
    Insert embedded KB chunks into PostgreSQL/pgvector.

    Each document should contain:
        content
        embedding
        metadata
    """

    if not embedded_documents:
        return 0

    # Determine embedding dimension from first vector
    embedding_dimension = len(embedded_documents[0]["embedding"])

    # Make sure table exists
    create_vector_table(embedding_dimension)

    db = get_db_conn()

    try:

        inserted_count = 0

        for document in embedded_documents:

            content = document["content"]

            embedding = document["embedding"]

            metadata = document.get(
                "metadata",
                {},
            )

            embedding_string = "[" + ",".join(str(value) for value in embedding) + "]"

            db.execute(
                text("""
                    INSERT INTO knowledge_documents
                    (
                        content,
                        embedding,
                        metadata
                    )
                    VALUES
                    (
                        :content,
                        CAST(
                            :embedding AS vector
                        ),
                        CAST(
                            :metadata AS jsonb
                        )
                    )
                    """),
                {
                    "content": content,
                    "embedding": embedding_string,
                    "metadata": json.dumps(metadata),
                },
            )

            inserted_count += 1

        db.commit()

        return inserted_count

    except Exception:
        db.rollback()
        raise

    finally:
        db.close()


def get_document_count() -> int:
    """
    Return the number of documents currently
    stored in the vector table.
    """

    db = get_db_conn()

    try:

        result = db.execute(text("""
                SELECT COUNT(*)
                FROM knowledge_documents
                """))

        return result.scalar_one()

    finally:
        db.close()
