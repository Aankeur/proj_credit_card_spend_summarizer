from sqlalchemy import text

from src.core.db import get_db_conn


def create_vector_table(
    embedding_dimension: int,
):
    """
    Create the pgvector extension and document table.
    """

    db = get_db_conn()

    try:

        db.execute(
            text(
                "CREATE EXTENSION IF NOT EXISTS vector"
            )
        )

        db.execute(
            text(
                f"""
                CREATE TABLE IF NOT EXISTS knowledge_documents (
                    id SERIAL PRIMARY KEY,
                    content TEXT NOT NULL,
                    embedding VECTOR({embedding_dimension}),
                    metadata JSONB
                )
                """
            )
        )

        db.commit()

    finally:

        db.close()


def insert_documents(
    embedded_documents: list[dict],
):
    """
    Insert embedded KB chunks into PostgreSQL/pgvector.
    """

    if not embedded_documents:
        return 0

    embedding_dimension = len(
        embedded_documents[0]["embedding"]
    )

    create_vector_table(
        embedding_dimension
    )

    db = get_db_conn()

    try:

        for document in embedded_documents:

            embedding = document["embedding"]

            embedding_string = (
                "["
                + ",".join(
                    str(value)
                    for value in embedding
                )
                + "]"
            )

            db.execute(
                text(
                    """
                    INSERT INTO knowledge_documents
                    (
                        content,
                        embedding,
                        metadata
                    )
                    VALUES
                    (
                        :content,
                        CAST(:embedding AS vector),
                        CAST(:metadata AS jsonb)
                    )
                    """
                ),
                {
                    "content": document["content"],
                    "embedding": embedding_string,
                    "metadata": __import__(
                        "json"
                    ).dumps(
                        document["metadata"]
                    ),
                },
            )

        db.commit()

        return len(embedded_documents)

    except Exception:

        db.rollback()

        raise

    finally:

        db.close()